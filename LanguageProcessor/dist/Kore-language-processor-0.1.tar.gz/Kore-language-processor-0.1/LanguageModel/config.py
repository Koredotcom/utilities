MECAB_KO_DIR = '/data/FAQ/Korean/mecab/lib/mecab/dic/mecab-ko-dic'

